package co.com.bdb.automation.definitions;

import io.restassured.response.Response;

public class BaseTest {
    Response response;
}
